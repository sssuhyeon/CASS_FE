const MainStudent = () => {
return(
    <div>
        MainStudent 페이지입니다.
    </div>
);
};

export default MainStudent;